# Task 1: Predict Restaurant Ratings

This task builds a regression model to predict restaurant ratings based on cuisine, price, service, and ambience.

## How to Run
1. Install requirements:
   ```
   pip install pandas scikit-learn
   ```
2. Run the script:
   ```
   python main.py
   ```

## Dataset
- `restaurant_ratings.csv` contains sample data with relevant features.

## Output
- Mean Squared Error and R² Score.
